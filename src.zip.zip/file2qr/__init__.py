def hello():
    return "Hello from file2qr!"
